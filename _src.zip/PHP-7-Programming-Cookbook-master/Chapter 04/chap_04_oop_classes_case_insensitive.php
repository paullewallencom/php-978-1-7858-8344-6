<?php
// demonstrates that classes are case-insensitive


// generates a fatal error (which cannot be caught)
require __DIR__ . '/TwoClass.php';
