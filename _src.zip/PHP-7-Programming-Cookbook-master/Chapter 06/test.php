<?php
$a = ['*' => 'test'];
echo $a['*'];
