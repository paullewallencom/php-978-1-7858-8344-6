<?php
    // page 1
?>
<h1>Page 1</h1>
<hr>
<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. An est aliquid per se ipsum flagitiosum, etiamsi nulla comitetur infamia? Atque hoc loco similitudines eas, quibus illi uti solent, dissimillimas proferebas. Est enim effectrix multarum et magnarum voluptatum. Nescio quo modo praetervolavit oratio. An hoc usque quaque, aliter in vita? Duo Reges: constructio interrete. Primum in nostrane potestate est, quid meminerimus? Non potes, nisi retexueris illa. Ut aliquid scire se gaudeant? </p>
<p>Quod non faceret, si in voluptate summum bonum poneret. Quid autem habent admirationis, cum prope accesseris? Quo plebiscito decreta a senatu est consuli quaestio Cn. Ita ne hoc quidem modo paria peccata sunt. Non igitur de improbo, sed de callido improbo quaerimus, qualis Q. Nam ista vestra: Si gravis, brevis; Cum id fugiunt, re eadem defendunt, quae Peripatetici, verba. Nos quidem Virtutes sic natae sumus, ut tibi serviremus, aliud negotii nihil habemus. Itaque primos congressus copulationesque et consuetudinum instituendarum voluntates fieri propter voluptatem; Ex ea difficultate illae fallaciloquae, ut ait Accius, malitiae natae sunt. Fortasse id optimum, sed ubi illud: Plus semper voluptatis? </p>
