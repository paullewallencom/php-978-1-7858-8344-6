<?php
    $_SESSION['info'] = FALSE;
    session_destroy();
?>
<a href="/">BACK</a>
