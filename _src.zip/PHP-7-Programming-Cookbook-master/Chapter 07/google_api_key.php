<?php 
echo <<<EOQ
You need to return your Google API key as a string
see: https://developers.google.com/maps/documentation/directions/get-api-key
see: https://developers.google.com/maps/documentation/directions/intro#Introduction
EOQ;
