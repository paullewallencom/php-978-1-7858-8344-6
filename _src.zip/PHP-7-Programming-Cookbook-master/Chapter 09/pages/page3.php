<?php
    // intermediate content
?>
<h1>Page 3</h1>
<hr>
<p>Qua igitur re ab deo vincitur, si aeternitate non vincitur? Haec igitur Epicuri non probo, inquam. Non est ista, inquam, Piso, magna dissensio. Quo modo autem philosophus loquitur? At eum nihili facit; Quod ea non occurrentia fingunt, vincunt Aristonem; Quid enim ab antiquis ex eo genere, quod ad disserendum valet, praetermissum est? </p>
<p>Beatus sibi videtur esse moriens. Graecum enim hunc versum nostis omnes-: Suavis laborum est praeteritorum memoria. Quae autem natura suae primae institutionis oblita est? Sic enim maiores nostri labores non fugiendos tristissimo tamen verbo aerumnas etiam in deo nominaverunt. Age sane, inquam. Non dolere, inquam, istud quam vim habeat postea videro; </p>
<p>Huic mori optimum esse propter desperationem sapientiae, illi propter spem vivere. Vide, quantum, inquam, fallare, Torquate. Sed haec quidem liberius ab eo dicuntur et saepius. Nihilne te delectat umquam -video, quicum loquar-, te igitur, Torquate, ipsum per se nihil delectat? Hoc non est positum in nostra actione. Apparet statim, quae sint officia, quae actiones. Num igitur eum postea censes anxio animo aut sollicito fuisse? Quis istud possit, inquit, negare? </p>
