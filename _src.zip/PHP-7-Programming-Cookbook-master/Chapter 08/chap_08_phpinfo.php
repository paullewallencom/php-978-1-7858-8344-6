<?php phpinfo(INFO_VARIABLES); ?>
