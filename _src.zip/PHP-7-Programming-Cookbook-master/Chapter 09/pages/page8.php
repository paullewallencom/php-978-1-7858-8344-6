<?php
    // intermediate content
?>
<h1>Page 8</h1>
<hr>
<p>Quid autem habent admirationis, cum prope accesseris? An vero, inquit, quisquam potest probare, quod perceptfum, quod. Positum est a nostris in iis esse rebus, quae secundum naturam essent, non dolere; Superiores tres erant, quae esse possent, quarum est una sola defensa, eaque vehementer. Multoque hoc melius nos veriusque quam Stoici. Consequentia exquirere, quoad sit id, quod volumus, effectum.</p>
<p>sEiuro, inquit adridens, iniquum, hac quidem de re; Sin aliud quid voles, postea. Te ipsum, dignissimum maioribus tuis, voluptasne induxit, ut adolescentulus eriperes P. Quid de Pythagora? Traditur, inquit, ab Epicuro ratio neglegendi doloris. Non modo carum sibi quemque, verum etiam vehementer carum esse? Ne amores quidem sanctos a sapiente alienos esse arbitrantur. </p>
