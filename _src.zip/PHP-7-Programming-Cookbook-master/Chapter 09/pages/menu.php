<?php // menu ?>
<a href="?page=1">Page 1</a>
<a href="?page=2">Page 2</a>
<a href="?page=3">Page 3</a>
<a href="?page=4">Page 4</a>
<a href="?page=5">Page 5</a>
<a href="?page=6">Page 6</a>
<a href="?page=7">Page 7</a>
<a href="?page=8">Page 8</a>
<a href="?page=9">Page 9</a>
<a href="?page=logout">Logout</a>

