<?php
    // intermediate content
?>
<h1>Page 7</h1>
<hr>
<p>Proclivi currit oratio. Si quae forte-possumus. Aeque enim contingit omnibus fidibus, ut incontentae sint. Quare, quoniam de primis naturae commodis satis dietum est nunc de maioribus consequentibusque videamus. Tum ille timide vel potius verecunde: Facio, inquit. Nec enim, dum metuit, iustus est, et certe, si metuere destiterit, non erit; Omnia contraria, quos etiam insanos esse vultis.</p>
<p>Ait enim se, si uratur, Quam hoc suave! dicturum. Istam voluptatem perpetuam quis potest praestare sapienti? Etenim nec iustitia nec amicitia esse omnino poterunt, nisi ipsae per se expetuntur. Sit enim idem caecus, debilis. Sed non sunt in eo genere tantae commoditates corporis tamque productae temporibus tamque multae. Quis non odit sordidos, vanos, leves, futtiles? Satis est tibi in te, satis in legibus, satis in mediocribus amicitiis praesidii. Quod quidem nobis non saepe contingit. Duae sunt enim res quoque, ne tu verba solum putes. Quid ergo aliud intellegetur nisi uti ne quae pars naturae neglegatur? </p>
