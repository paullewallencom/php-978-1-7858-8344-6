<?php
// Used to test autolading
namespace Application\Test;

class TestClass
{
    public function getTest()
    {
        return __METHOD__;
    }
}
    
