<?php
namespace Xyz;

trait Test
{
    public $name = 'TEST';
}
